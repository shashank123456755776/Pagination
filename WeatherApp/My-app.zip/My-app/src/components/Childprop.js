import React from "react";
//Child Componenets
const Childprop= ({ thumbnail, title ,description}) => {
    return (
               
        <>
            <img src={thumbnail} alt={thumbnail} />
            <h2>{title}</h2>
              <h3>{description}</h3>
              </>

        
    );
};
export default Childprop;