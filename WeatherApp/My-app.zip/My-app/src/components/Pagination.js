import React from "react";
const Pagination = ({
    total,
    skip,
    setpresentpage,
    PresentPage,
}) => {
    let mypage = [];

    for (let i = 1; i <= Math.ceil(total/skip); i++) {
     mypage.push(i);
    }

    return (
        <div >
            {mypage.map((page) => {
                return (
                    <button
                        onClick={() => setpresentpage(page)}>
                        {page}
                    </button>
                );
            })}
        </div>
    );
};
export default Pagination;