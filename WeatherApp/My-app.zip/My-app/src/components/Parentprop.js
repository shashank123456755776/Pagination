import React from "react";

import Childprop from "./Childprop";
//parent componenets
const Parentprop = ({ mywholedata }) => {
    // console.log(mywholedata)
    return (
        <div >
            {mywholedata.map((meredata) => {
                return (
                    <Childprop
                    
                        description={meredata.description}
                        thumbnail={meredata.thumbnail}
                        title={meredata.title}
            
                    />
                );
            })}
        </div>
    );
};

export default Parentprop;