import React, { useEffect, useState } from "react";
import axios from "axios";


import Parentprop from './components/Parentprop';
import Pagination from "./components/Pagination";


function App() {

//three states we define one for store fetching data in arary/one for rendering 10 pages in one clcik and third for current page
    const [mywholedata, setmywholedata] = useState([]);
    const [presentpage, setpresentpage] = useState(1);
    const [skip, setskip] = useState(10);
//fetching of data from api using axios method
    const getData = async () => {
      const res = await axios.get(
     `https://dummyjson.com/products?limit=100`
      );   
      setmywholedata(res.data.products);
      
    };// run after rendering usestates
  useEffect(() => {

    getData();

  }, [])
  
    console.log(mywholedata)
 //Here we wanna do slicing of page in 10 page from 100 pages
    const lastindex = presentpage *skip;
    const firstindex = lastindex -skip;
    const mypost = (mywholedata || []).slice(firstindex,lastindex);

    return (
        <div >
            <h1>Shashank web application</h1>
            <Parentprop mywholedata = {mypost} />

            <Pagination
             total={mywholedata.length}
             skip={skip}
             presentpage={presentpage}
             setpresentpage={setpresentpage}
            />
           
        </div>
    );
}

export default App;
